# generatorSqlmapCustom
Mybatis 的逆向工程，可用于生成 pojo 类、Mapper接口、mapper.xml映射文件
